fetch('https://www.el-tiempo.net/api/json/v1/provincias/01/municipios/01001')
  .then(response => response.json())
  .then(data => {
    const datosDiv = document.getElementById('datos');
    const tabla = document.createElement('table');
    tabla.classList.add('table');
    datosDiv.appendChild(tabla);

    
    for (const propiedad in data) {
      const fila = document.createElement('tr');
      tabla.appendChild(fila);

      const nombreCelda = document.createElement('td');
      nombreCelda.textContent = propiedad.replace(/_/g, ' ');
      fila.appendChild(nombreCelda);

      const valorCelda = document.createElement('td');
      valorCelda.textContent = data[propiedad];
      fila.appendChild(valorCelda);
    }
  })
  .catch(error => {
    console.error('Error al realizar la petición:', error);
  });
